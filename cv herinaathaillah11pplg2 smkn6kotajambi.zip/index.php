<?php
require 'function.php';
$cari= mysqli_query($database,"select*from admin");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Herina</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div class="header">
    <div class="gambar"> <img src="erin.jpg" alt="ini gambar saya">
    </div>
    <?php
        foreach( $cari as $cari2):

        ?>
    <h1><?php echo $cari2["nama"] ?> </h1>
    <h3><?php echo $cari2["hobi"] ?></h3>
    <?php
        endforeach;
        ?>
    </div>
    <div class="main">
        <div class="left">
            <h2>Informasi identitas</h2>
            <p><strong>Nama :</strong> <?php echo $cari2["nama"] ?></p>
            <p><strong>Alamat :</strong> <?php echo $cari2["alamat"] ?></p>
            <p><strong>No telp :</strong> <?php echo $cari2["no_hp"] ?></p>
            <p><strong>Skill :</strong> <?php echo $cari2["skill"] ?></p>
            <h2>Pendidikan</h2>
            <p><strong><?php echo $cari2["pendidikan"] ?></strong></p>
            </div>
        <div class="right">
            <h2>Pekerjaan</h2>
            <p><strong><?php echo $cari2["pekerjaan"] ?></strong></p>
            <h3>Keperibadian</h3>
            <p><strong>Sifat</strong></p>
            <li>Menghargai pendapat</li>
            <li>Gampang bergaul</li>
        </div>
    </div>
    </div>
</body>
</html>