<?php
session_start();
$database=mysqli_connect("localhost","root","","cv");
if(isset ($_POST ["tombol"])){
$Username=$_POST ["username"];
$Password=$_POST ["password"];
$cari=mysqli_query ($database,"select*from login where
username='$Username' and password='$Password'");
if(mysqli_num_rows($cari)=== 1){
    $_SESSION ["login"]=true;
    header("Location: data-admin.php");
    exit;
}
$error=true;

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login admin CV</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  
  <div class="container">
    <div class="myform">
    <?php if (isset($error)): ?>
        <p>User/Password salah</p>
        <?php endif; ?>
      <form method="post">
        <h2>ADMIN LOGIN</h2>
        <input type="text" name="username" placeholder="Username">
        <input type="password" name="password" placeholder="Password">
        <button type="submit" name="tombol" >LOGIN</button>
      </form>
    </div>
    <div class="image">
      <img src="logo.JPG">
    </div>
  </div>
</body>
</html>