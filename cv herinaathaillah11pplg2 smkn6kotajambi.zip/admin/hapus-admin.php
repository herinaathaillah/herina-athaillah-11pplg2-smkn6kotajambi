<?php
require 'function.php';
$hapus=$_GET["no"];
if(hapusAdmin($hapus)>0){
    echo "
    <script>
    alert('Data Berhasil Dihapus');
    document.location.href='data-admin.php';
    </script>
    ";
    }
    else{echo"Gagal";}



?>