<?php
session_start();
if (!isset($_SESSION["login"])){
    header("Location: login.php");
    exit;
}
require 'function.php';
if(isset($_POST["tombol"])){
    if(tambahAdmin($_POST)>0){
        echo "
        <script>
        alert('Data Berhasil Ditambahkan');
        document.location.href='data-admin.php';
        </script>
        ";
        }
        else{echo"Gagal";}

}
    

?>
<!doctype html>
<html>
<head>
<title>
Tambah Admin


</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
<div class="header">
<div class="header-logo">
             <img src="logo.JPG" alt="ini gambar logo">
          </div>
          <div class="header-title">
          <a href="index.php"> Website admin CV</a>
          </div>
          </div>
          <ul class="menu">
        <li class="menu-item"><a href="data-cv.php">Data cv</a></li>
        <li class="menu-item"><a href="data-admin.php">Data admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>

      
          </ul>
          <div class="konten">



<h1> Tambah Admin </h1>
<br>
<form method="POST">

<ul>
<li><label> Nama </label></li>
<li><input type="text" name="nama"></li>

<li><label> Jenis kelamin </label></li>
<li>
  <select name="jenis_kelamin" required>
  <option>Laki-laki</option>
  <option>Perempuan</option>
  </select>
</li>

<li><label> Alamat </label></li>
<li><input type="text" name="alamat"></li>
<li><label> No hp </label></li>
<li><input type="text" name="no_hp"></li>
<li><label> Skill </label></li>
<li><input type="text" name="skill"></li>
<li><label> Hobi </label></li>
<li><input type="text" name="hobi"></li>

<li><label> Pendidikan </label></li>
<li><textarea name="pendidikan" id=""></textarea></li>

<li><label> Pekerjaan </label></li>
<li><textarea name="pekerjaan" id=""></textarea></li>

<li><button type="submit" name="tombol"> Simpan </button> </li>
</ul>

</form>
</body>
</html> 