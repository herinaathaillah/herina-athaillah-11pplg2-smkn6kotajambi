<?php
$database= mysqli_connect("localhost","root","","cv");

function query ($query){
    global $database;
  $tampilkan = mysqli_query($database, $query);
  $wadahkosong = [];
  while( $data =mysqli_fetch_assoc($tampilkan)){
    $wadahkosong [] =$data;
  }
  return $wadahkosong;
}
function tambah ($tambah){
    global $database;
    $no_kamar=$_POST["no_kamar"];
    $nama=$_POST["nama"];
    $no_hp=$_POST["no_hp"];
    $tipe_kamar=$_POST["tipe_kamar"];
    $harga=$_POST["harga"];
    $checkin=$_POST["checkin"];
    $checkout=$_POST["checkout"];
    $tambah_resevarsi="insert into resevarsi values
    ('','$no_kamar','$nama','$no_hp','$tipe_kamar','$harga','$checkin','$checkout')"; 
   
    mysqli_query($database,$tambah_resevarsi);
    return mysqli_affected_rows($database);
}
function hapus ($hapus){
    global $database;
    mysqli_query($database,"delete from resevarsi where no=$hapus");
    return mysqli_affected_rows($database);
}
function edit ($edit){
    global $database;
    $hapus=$_GET["no"];
    mysqli_query($database,"select*from resevarsi where no=$hapus");
    $no_kamar=$_POST["no_kamar"];
    $nama=$_POST["nama"];
    $no_hp=$_POST["no_hp"];
    $tipe_kamar=$_POST["tipe_kamar"];
    $harga=$_POST["harga"];
    $checkin=$_POST["checkin"];
    $checkout=$_POST["checkout"];
    $edit="update resevarsi set

   no_kamar ='$no_kamar',
   nama ='$nama',
   no_hp ='$no_hp',
   tipe_kamar ='$tipe_kamar',
   harga ='$harga',
   checkin ='$checkin',
    checkout ='$checkout'

   
   where no=$hapus";
    mysqli_query($database, $edit);
    return mysqli_affected_rows($database);
}
function tambahAdmin($tambahAdmin){
    global $database;
    $nama=$_POST["nama"];
    $jenis_kelamin=$_POST["jenis_kelamin"];
    $alamat=$_POST["alamat"];
    $no_hp=$_POST["no_hp"];
    $skill=$_POST["skill"];
    $hobi=$_POST["hobi"];
    $pendidikan=$_POST["pendidikan"];
    $pekerjaan=$_POST["pekerjaan"];
    $tambah_admin="insert into admin values
    ('','$nama','$jenis_kelamin','$alamat','$no_hp','$skill','$hobi','$pendidikan','$pekerjaan')"; 
    mysqli_query($database,$tambah_admin);
    return mysqli_affected_rows($database);
}
function hapusAdmin($hapusAdmin){
    global $database;
    mysqli_query($database,"delete from admin where no=$hapusAdmin");
    return mysqli_affected_rows($database);
}
function editAdmin($editAdmin){
    global $database;
    $hapus=$_GET["no"];

    $nama=$_POST["nama"];
    $jenis_kelamin=$_POST["jenis_kelamin"];
    $alamat=$_POST["alamat"];
    $no_hp=$_POST["no_hp"];
    $skill=$_POST["skill"];
    $hobi=$_POST["hobi"];
    $pendidikan=$_POST["pendidikan"];
    $pekerjaan=$_POST["pekerjaan"];
    $edit = "update admin set  
    nama = '$nama',
    jenis_kelamin = '$jenis_kelamin',
    alamat = '$alamat',
    no_hp = '$no_hp',
    skill = '$skill',
    hobi = '$hobi',
    pendidikan = '$pendidikan',
    pekerjaan ='$pekerjaan'
    where no =$hapus"; 
    mysqli_query($database,$edit);
    return mysqli_affected_rows($database);
}

?>