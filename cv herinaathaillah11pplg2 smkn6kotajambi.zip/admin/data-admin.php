<?php
session_start();
if (!isset($_SESSION["login"])){
    header("Location: login.php");
    exit;
}

require 'function.php';
$cari= mysqli_query($database,"select*from admin");
if(isset($_POST["tombol"])){
    $Pencarian= $_POST ["pencarian"];
   $datayangdicari="select *from admin where
    no like '%$Pencarian%' or
    nama like '%$Pencarian%' or
    jenis_kelamin like '%$Pencarian%' or
    alamat like '%$Pencarian%' or
    no_hp like '%$Pencarian%' or
    skill like '%$Pencarian%' or
    hobi like '%$Pencarian%' or
    pendidikan like '%$Pencarian%' or
    pekerjaan like '%$Pencarian%'";
    $cari=mysqli_query($database,$datayangdicari);

} else{
    $cari=mysqli_query($database,"select*from admin");
}

?>
<!doctype html>
<html>
<head>
<title>
Website admin

</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
<div class="header-logo">
             <img src="logo.JPG" alt="ini gambar logo">
          </div>
          <div class="header-title">
          <a href="index.php">Website admin CV</a> 
          </div>
          </div>
          <ul class="menu">
        <li class="menu-item"><a href="index.php">Data cv</a></li>
        <li class="menu-item"><a href="data-admin.php">Data admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>


      
          </ul>
          <div class="konten">

    <h1> Daftar Admin </h1>
    <a href="tambah-admin.php">Tambah Admin</a>
    <form action="" method="post">
        <input type="text" name="pencarian">
        <button type="submit" name="tombol">Cari</button>
    </form>
    <table border="1" cellpadding="10" cellspacing="0">
    <tr class="table-header">
        <th>No</th>
        <th>Nama</th>
        <th>Jenis kelamin</th>
        <th>Alamat</th>
        <th>No hp</th>
        <th>Skill</th>
        <th>Hobi</th>
        <th>Pendidikan</th>
        <th>Pekerjaan</th>
        <th>Aksi</th>
       
        </tr>

        <?php
        $aku=1;
        ?>
    

        
        <?php
        foreach( $cari as $cari2):

        ?>
        <tr><td class="table-header1"><?php echo $aku; ?></td>
        <td class="table-header2"><?php echo $cari2["nama"] ?></td>
        <td class="table-header3"><?php echo $cari2["jenis_kelamin"] ?></td>
        <td class="table-header4"><?php echo $cari2["alamat"] ?></td>
        <td class="table-header5"><?php echo $cari2["no_hp"] ?></td>
        <td class="table-header6"><?php echo $cari2["skill"] ?></td>
        <td class="table-header8"><?php echo $cari2["hobi"] ?></td>
        <td class="table-header9"><?php echo $cari2["pendidikan"] ?></td>
        <td class="table-header10"><?php echo $cari2["pekerjaan"] ?></td>
        <td class="table-header7"><a href="edit-admin.php?no=<?php echo $cari2["no"] ?>">Edit</a> |
            <a href="hapus-admin.php?no=<?php echo $cari2["no"] ?>">Hapus</a></td>
        </tr>

        <?php
        $aku++;
        ?>

        <?php
        endforeach;
        ?>

    </table>
    </body>
    </html>